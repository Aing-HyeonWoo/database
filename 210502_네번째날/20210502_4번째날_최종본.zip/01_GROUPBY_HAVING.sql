use madang;

select * from orders order by custid; 

# 고객별로 주문한 도서의 총 수량과 총 판매액
select custid, count(*) as 도서수량, sum(saleprice) as 총액 from orders group by custid;

select * from orders group by custid; #집계함수(sum이나 count같은) 없이 사용하면 데이터가 뭉개짐

#고객이 주문한 도서의 총 판매액
select sum(saleprice) from orders; # 단순하게 총 판매액만 계산할 수 있음

#HAVING  #GROUP BY 계의 WHERE 절이라고 보시면 됩니다.
# 가격이 8000이상인 도서를 구매한 고객에 대하여, 고객별 주문 도서의 총 수량을 구하시오.(WHERE)
# 근데 두 권 이상 구매한 고객만 구해야 한다(HAVING)

#여기까지만 적으면, 주문 가격이 8000원 이상인 고객들의 총 도서 수량만 나와요.
SELECT CUSTID, COUNT(*) AS 도서수량 FROM ORDERS WHERE SALEPRICE >= 8000 GROUP BY CUSTID;

# 8000원 이상 구매한 고객만 나타냄
SELECT CUSTID, SALEPRICE FROM ORDERS WHERE SALEPRICE >= 8000;
#도서수량이 2권 이상인 고객만 나타내고 싶다!
SELECT CUSTID, COUNT(*) AS 도서수량 FROM ORDERS WHERE SALEPRICE >= 8000 GROUP BY CUSTID HAVING COUNT(*) >= 2;

#주문 관리 테이블
SELECT * FROM ORDERS ORDER BY CUSTID;

#이 중에서 주문 가격이 8000원 이상인 것만 조회합니다.
SELECT * FROM ORDERS WHERE SALEPRICE >= 8000 ORDER BY CUSTID;

#고객별(CUSTID별) 도서 수량 조회
SELECT CUSTID, COUNT(*) AS 도서수량 FROM ORDERS WHERE SALEPRICE >= 8000 group by CUSTID;

#고객별 도서 수량을 조회하되, 수량이 2개 이상인 것만 조회
#CTRL+SPACE 통하여 자동완성되는 키워드 쓰기(그래야 빨리 작업가능!)
#having은 group by 다음에 나와야 한다~!
SELECT CUSTID, COUNT(*) AS 도서수량 FROM ORDERS WHERE SALEPRICE >= 8000 group by custid having 도서수량 >= 2;


