#join 공부 더 하기
SELECT * FROM myschool.hakgwatable;
#038
#123
#385
#813
select * from student;
INSERT INTO `myschool`.`student` (`hakbeon`, `name`, `age`, `HakGwaCode`, `hakjeom`, `phoneNum`) VALUES ('2010385123', '김범수', '23', '385', '2.7', '010-1226-1234');
INSERT INTO `myschool`.`student` (`hakbeon`, `name`, `age`, `HakGwaCode`, `hakjeom`, `phoneNum`) VALUES ('2011813888', '백진음', '37', '813', '4.25', '010-7777-4234');
INSERT INTO `myschool`.`student` (`hakbeon`, `name`, `age`, `HakGwaCode`, `hakjeom`, `phoneNum`) VALUES ('2020813999', '한웅희', '13', '813', '2.78', '010-2233-1234');
INSERT INTO `myschool`.`student` (`hakbeon`, `name`, `age`, `HakGwaCode`, `hakjeom`, `phoneNum`) VALUES ('2021123874', '최재훈', '28', '123', '4.44', '010-4444-1234');
INSERT INTO `myschool`.`student` (`hakbeon`, `name`, `age`, `HakGwaCode`, `hakjeom`, `phoneNum`) VALUES ('2019038111', '이동준', '25', '038', '1.0', '010-2381-1234');
INSERT INTO `myschool`.`student` (`hakbeon`, `name`, `age`, `HakGwaCode`, `hakjeom`, `phoneNum`) VALUES ('2013038099', '서현우', '23', '038', '4.15', '010-2222-4321');
INSERT INTO `myschool`.`student` (`hakbeon`, `name`, `age`, `HakGwaCode`, `hakjeom`, `phoneNum`) VALUES ('2015038011', '김규창', '33', '038', '3.75', '010-2222-2234');
INSERT INTO `myschool`.`student` (`hakbeon`, `name`, `age`, `HakGwaCode`, `hakjeom`, `phoneNum`) VALUES ('2017123123', '표서윤', '25', '123', '4.41', '010-4332-5446');

select * from student;

#join!
#학과테이블과 학생테이블을 조인해보자.
select * from student, hakgwatable where student.HakGwaCode = hakgwatable.code;

#join 키워드 없이 join하기
select hakbeon, student.name, hakgwatable.name from student, hakgwatable 
where student.HakGwaCode = hakgwatable.code;

#join 키워드 사용해서 join하기
#콤마 대신 join 적고 where 대신에 on을 적으면 끝!
select hakbeon, student.name, hakgwatable.name from student join hakgwatable 
on student.HakGwaCode = hakgwatable.code;

#학과별 평점
select AVG(student.HAKJEOM), hakgwatable.NAME from student join hakgwatable 
on student.HakGwaCode = hakgwatable.code GROUP BY hakgwatable.NAME;

#평점이 3.0 미만인 학과를 출력하시오.(학과이름만 출력하면 됨) 
-- HAVING (AS 키워드를 이용해야 할 듯. 안 해도 되지만)
select hakgwatable.NAME AS '4.0미만 과' from student join hakgwatable 
on student.HakGwaCode = hakgwatable.code GROUP BY 
hakgwatable.NAME HAVING AVG(student.HAKJEOM) < 4.0;

#우리가 여태 배운 건 INNER JOIN
# LEFT OUTER JOIN, RIGHT OUTER JOIN, SELF 조인











