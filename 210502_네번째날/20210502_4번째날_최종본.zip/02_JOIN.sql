# join
# 두 개의 테이블을 합치는 작업

#무식하게 합쳐보기
select * from book; #길이 10
select * from customer; #길이 5
select * from orders; # 길이 10
#그냥 단순하게 두 개의 테이블을 그냥 이어붙인거임
select * from customer, orders; #길이 50

# 고객과 고객의 주문에 관한 데이터를 모두 보이시오! (이런 것을 join이라고 함)
select * from customer, orders where customer.custid = orders.custid;

# 문제
# 고객과 고객의 주문에 관한 데이터를 고객번호 순으로 정렬하되, 역순으로 정렬해주세요.
select * from customer, orders where customer.custid = orders.custid order by customer.custid desc;

#고객과 고객의 주문에 관한 데이터를 고객의 이름순(가나다순)으로 정렬하기
select * from customer, orders where customer.custid = orders.custid order by customer.name;

# 고객별 총 판매액을 출력해주세요.(두 개의 테이블 합치기 = 조인)
select name as 고객명, sum(saleprice) as 총액 from customer, orders 
where customer.custid = orders.custid group by customer.name;

#테이블명을 줄일 수 있음
#여기서 주의할 점은! 키워드랑 겹치는 이름을 지정하면 안 됨! (예를 들어서 orders as order 이런 거 안 됨.)
#여기서 키워드란 order, select처럼 이미 mysql 상에서 지정된 단어들을 의미합니다.
select name as 고객명, sum(saleprice) as 총액 from customer as cs, orders as os 
where cs.custid = os.custid group by cs.name;
#테이블 명칭을 as를 통해서 변경하면 그 변경된 명칭된 써야 됨. 즉 여기선 cs로 바꿨으면 customer는 쓰면 안 됨

#조인을 하는 또 다른 방법(where절 대신에 사용함)
# 두개의 테이블 사이에 콤마(,) 대신에 join 넣고, where 대신에 on을 넣는다.
select name as 고객명, sum(saleprice) as 총액 from customer as cs join orders as os 
on cs.custid = os.custid group by cs.name;



