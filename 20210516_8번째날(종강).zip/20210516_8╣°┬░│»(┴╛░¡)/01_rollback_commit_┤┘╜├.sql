SELECT * FROM finalstudy.test_commit_rollback;

insert into test_commit_rollback(name) values('임영준');

delete from test_commit_rollback where seq=4;

delete from test_commit_rollback;

#실수 했을 때 다시 되돌리기 위해서는 실수하기 전 시점을 저장할 수 있어야 한다~!
#mysql은 자동적으로 항상 저장을 한다.

#방법1 autocommit을 아래 명령어 이용하여 꺼줘야 한다.
set autocommit = 0;
#방법2
#화면 상단의 Query -> Auto commit transaction을 꺼준다.

#확인방법 - 0값이 있어야 '수동으로 저장 및 되돌리기가 가능'
select @@autocommit from dual;

# commit - 저장
# rollback - 되돌리기
# transaction(트랜잭션) - insert, update, delete처럼 테이블값을 변화시키는 명령

#autocommit 기능은 mysql을 켤때마다 항상 켜지므로 주의하자

#저장 및 복구방법1 (savepoint 이용하는 것)
select * from test_commit_rollback;
savepoint a; #아무 것도 없는 시점에 저장함 
insert into test_commit_rollback(seq,name) values (1,'류수현');
savepoint b; #사람 한 명 추가하고 save함
insert into test_commit_rollback(seq,name) values (2, '김규창');
rollback to savepoint a; #savepoint a로 돌아가게 되면 savepoint b가 없는 시점이므로 b로 못 간다.
rollback to savepoint b; #사람이 한 명 있었던 시점으로 돌아갑니다.







