INSERT INTO student (`hakbeon`, `name`, `grade`, `cm`, `department`) VALUES ('07002', '김길동', '4', 168, 'CD');
INSERT INTO student (`hakbeon`, `name`, `grade`, `cm`, `department`) VALUES ('07012', '박길동', '2', 180, 'CD');
INSERT INTO student (`hakbeon`, `name`, `grade`, `cm`, `department`) VALUES ('08001', '홍길동', '2', 170, 'CD');
INSERT INTO student (`hakbeon`, `name`, `grade`, `cm`, `department`) VALUES ('07033', '이길동', '3', 175, 'ID');
INSERT INTO student (`hakbeon`, `name`, `grade`, `cm`, `department`) VALUES ('05014', '최길동', '4', 183, 'ED');
INSERT INTO student (`hakbeon`, `name`, `grade`, `cm`, `department`) VALUES ('06032', '정길동', '3', 165, 'ED');




INSERT INTO seolgang (`beonho`, `professor`, `gwamok`, `department`) VALUES ('101', '김일삼', 'SE', 'CD');
INSERT INTO seolgang (`beonho`, `professor`, `gwamok`, `department`) VALUES ('102', '권오영', 'DB', 'CD');
INSERT INTO seolgang (`beonho`, `professor`, `gwamok`, `department`) VALUES ('103', '김소월', 'DG', 'MD');
INSERT INTO seolgang (`beonho`, `professor`, `gwamok`, `department`) VALUES ('104', '이상', 'FP', 'CD');
INSERT INTO seolgang (`beonho`, `professor`, `gwamok`, `department`) VALUES ('105', '이석영', 'CS', 'ED');



INSERT INTO soogang (`student_hakbeon`, `seolgang_beonho`, `score`) VALUES ('08001', '101', '95');
INSERT INTO soogang (`student_hakbeon`, `seolgang_beonho`, `score`) VALUES ('08001', '102', '80');
INSERT INTO soogang (`student_hakbeon`, `seolgang_beonho`, `score`) VALUES ('08001', '103', '60');
INSERT INTO soogang (`student_hakbeon`, `seolgang_beonho`, `score`) VALUES ('08001', '104', '80');
INSERT INTO soogang (`student_hakbeon`, `seolgang_beonho`, `score`) VALUES ('08001', '105', '85');
INSERT INTO soogang (`student_hakbeon`, `seolgang_beonho`, `score`) VALUES ('07002', '101', '80');
INSERT INTO soogang (`student_hakbeon`, `seolgang_beonho`, `score`) VALUES ('07002', '104', '95');
INSERT INTO soogang (`student_hakbeon`, `seolgang_beonho`, `score`) VALUES ('07012', '102', '70');
INSERT INTO soogang (`student_hakbeon`, `seolgang_beonho`, `score`) VALUES ('07012', '103', '80');
INSERT INTO soogang (`student_hakbeon`, `seolgang_beonho`, `score`) VALUES ('07033', '102', '85');
INSERT INTO soogang (`student_hakbeon`, `seolgang_beonho`, `score`) VALUES ('05014', '104', '90');
INSERT INTO soogang (`student_hakbeon`, `seolgang_beonho`, `score`) VALUES ('05014', '105', '75');
