#주의 사항

#delete는 rollback으로 복원이 되지만 droptable은 rollback으로도 복원이 안 됩니다.

#delete는 특정 값을 지우거나 테이블 안에 있는 데이터들을 지우지만
#drop은 테이블 자체를 날려버림 
select * from test_commit_rollback;
start transaction;
insert into test_commit_rollback(name) values ('김재현');
commit; #데이터 추가하고 혹시 몰라서 저장까지 한다.
#delete로 날린 경우
delete from test_commit_rollback;
rollback; #다시 복구가 가능함.

#하지만 drop은...
drop table test_commit_rollback; #아예 테이블 자체가 날라가버린거다. 그래서 복구 안 됨....