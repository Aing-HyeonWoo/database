# 이번에는 세이브 포인트를 일일히 지정하는 방식이 아니고
# 가장 직전에 commit(=저장) 한 시점으로만 돌아가는 방식

select * from test_commit_rollback;
start transaction; 
commit;
insert into test_commit_rollback(seq, name) values (2, '이동준'); 
commit;

delete from test_commit_rollback;
#commit; #데이터 지우거나 update 할 땐 신중히!!!!!!!!
rollback; #가장 마지막에 저장한 지점으로 이동한다.