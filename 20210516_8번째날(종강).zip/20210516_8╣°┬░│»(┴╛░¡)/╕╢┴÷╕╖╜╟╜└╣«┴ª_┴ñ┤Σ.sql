USE final_que;


#1)  학생 table에서 학생의 이름, 신장을 출력하시오.
select name as 이름, cm as 신장 from Student;
#2)  학생 table에서 학번이 08001인 학생의 학번,이름,소속을 출력하시오.
select hakbeon,department,name from Student where hakbeon='08001';
#3)  학생 table에서 학년이 3학년이면서 소속이 ID인 학생의 모든정보를 구하시오.
select * from student where grade='3' and department='ID';
#4) 학생 table에서 신장이 170이상인 학생의 이름,신장,소속을 구하시오.
select name,cm,department from student where cm>=170;
#5) 수강테이블에서 성적이 80이상 90이하인 학생의 학번과 성적을 구하시오.
select * from soogang where score >= 80 and score<=90;
select * from soogang where score BETWEEN 80 and 90;
#6) 학생테이블에서 소속이 CD가 아닌 학생의 모든정보를 구하시오.
select * from student where department <>'CD';
#7) 설강테이블에서 교수명이 김으로 시작하는 정보의 교수명,과목명을 구하시오.
select professor,gwamok from seolgang where professor like '김%';
#8) 설강테이블에서 교수명이 이로 시작하면서 두자리인 교수명과 과목명을 구하시오.
select professor,gwamok from seolgang where professor like '이_';
#9) 설강테이블에서  교수명이 김씨가 아닌 모든 정보를 검색하시오.
select * from seolgang where professor not like '김%';
#10) 소속이 CD인 학생중 신장이 170이상 되는 학생의 학년과 신장을 구하시오.
select grade,cm from student where department='CD' and cm>=170;
#11) 학생테이블을 신장이 큰순에서 작은순서 대로 정렬하시오.
select * from student order by cm desc;
#12) 소속이 CD인 학생을 신장 크기 순으로 구하시오.
select * from student where department='CD' order by cm;
#13) 학생테이블에서 소속이 ID또는 ED가 아닌 학생의 모든 정보를 구하시오.
select * from student where department not in('ID','ED');
#14) 학생들의 평균 신장을 구하라.
select avg(cm) as avgheight from student;
#15) 소속별로 학생들의 평균 신장을 구하시오. # round : 소수점 자리 반올림 하는 함수
select round(avg(cm)) from student group by department;
#16) 수강테이블에서 학생별 평균성적을 구한후 평균성적이 높은 순서대로 정렬하시오.
select round(avg(score)) from soogang group by student_hakbeon order by round(avg(score)) desc;

#17) 교수번호 102인 교수가 설강한 과목을 수강하는 학생의 수를 계산하라.
select count(student_hakbeon) from soogang where seolgang_beonho = 102;
#18) 세과목 이상 수강하는 학생의 학번을 구하시오.
select student_hakbeon from soogang group by student_hakbeon having count(*) >= 3;
#19)  학생테이블중 소속이 CD인 학생만을 검색하여 학생10테이블로 복제하시오.
create table student10 like student; #student와 동일한 구조의 테이블을 만든다
insert into student10 (select * from student where department='cd'); #select 구문 이용하여 값을 넣음
 
#20) 성적이 80이상인 학생의 학번,이름,성적을 구하되 성적순으로 정렬하시오.(뷰 이용)
select a.hakbeon,name,Score from student a, (select * from soogang where score >= 80) b where a.hakbeon = b.student_hakbeon order by score desc;
select a.hakbeon,name,Score from student a, (select * from new_view) b where a.hakbeon = b.student_hakbeon order by score desc;