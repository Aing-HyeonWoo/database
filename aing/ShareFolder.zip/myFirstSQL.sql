show databases;  # 이러한 것들을 SQL 이라고 합니다.
# SQL : Structured Query Language(구조화 질의어)
# 주석!!
/*
여러 줄
주석
*/
select now() as 현재시간;